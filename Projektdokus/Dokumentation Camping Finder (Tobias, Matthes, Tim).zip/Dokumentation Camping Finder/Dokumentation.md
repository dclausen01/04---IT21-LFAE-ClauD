# Projekt Camping Finder

## <p align="center">Matthes Staacken - Tim Littschwager - Tobias Beckmann</p>

<p><br></p>

### Zielsetzung

Für die Umsetzung unseres Projekts haben wir uns an folgendem Modell orientiert:

<p><br></p>
<p align="center"><img src="./Kreislauf.png" alt="vollständige Handlung" width="40%"></p>
<p><br></p>

Das Ziel war es, eine Webseite zu entwickeln auf welcher Camping-Interessierte nach Zeltplätzen suchen und diese bewerten können. Ein Administrator soll diese Webseite zusätzlich mit neuen Datensätzen erweitern und vorhandene Datensätze bearbeiten können. Ausgangspunkt hierfür war das "lastMinuteCampingTentEdition"-Projekt aus Lernfeld 8. Dieses wurde mit Python verwaltet und besaß als Backend-Ersatz eine JSON-Datei, welche vom Frontend ausgelesen wurde.
Beim Camping Finder sollte ein echtes Backend zum Einsatz kommen. Zum einen um die Sicherheit und Datenintegrität zu erhöhen, zum anderen aber auch um Benutzern und dem Admin eine Anmelde-Möglichkeit zu bieten, um differenziert mit der Webseite zu interagieren. Die Webseite sollte dabei insgesamt intuitiv bedienbar, übersichtlich und ansprechend gestaltet sein und so den Anforderungen moderner "User-Interfaces" und "User-Designs" gerecht werden.

<p><br></p>

### Planung und Entscheidungsfindung

Im ersten Schritt der Planung befassten wir uns mit der Frage, was dargestellt werden sollte.

Da im vorausgegangenen Schuljahr bereits ein Datenbank-Projekt entstand in welchem wir eine mySQL-Datenbank zum Thema "Camping“ erstellten, waren wir uns schnell einig, dass wir hier ansetzen könnten.  
Der Aufbau des Datenbank-Projekts war sehr umständlich und bot nur wenige Funktionalitäten. So wurden Daten z.B. via Python verwaltet und jede Änderung in den Datensätzen gleichzeitig in die Datenbank als auch in eine JSON-Datei geschrieben. Diese JSON-Datei wurde anschließend vom Vue.js Frontend ausgelesen und angezeigt. Somit fungierte die JSON-Datei zwar als eine Art Backend, konnte allerdings weder Datenintegrität gewährleisten noch Anfragen sinnvoll validieren.
Um diese Nachteile und Probleme auszuräumen sollte unser neues Projekt ein echtes Backend bekommen. Auch die Benutzeroberfläche sollte überarbeitet werden. So sollte es Benutzern z.B. ermöglicht werden, Bewertungen für Campingplätze abzugeben.

<p><br></p>

Unser Projekt sollte insgesamt eine Übersicht zu Campingplätzen sowie deren freie Kapazitäten ermöglichen und diese interessierten Campern und Camperinnen zur Verfügung stellen können. Als eine der geläufigsten Varianten wählten wir hierfür eine browserbasierte Webansicht. Der große Vorteil dieser Darstellungsform ist , dass unsere Daten in jedem gängigen Internetbrowser visualisiert werden können.
Die Umsetzung selbst sollte mit `Laravel` und `Vue.js` erfolgen. Die Datenbank wird in Form eines `MySQL`-Servers realisiert.  
Bei Laravel handelt es sich um ein PHP-Framework welches wir für das Backend verwenden. Dieses regelt den Austausch der Daten zwischen Frontend und der Datenbank, um z.B. für Sicherheit zu sorgen, da der Quellcode hierdurch nicht einsehbar und manipulierbar wäre oder aber auch um Datenintegrität zu gewährleisten, wobei das Backend jeden Datenaustausch validiert und dadurch verhindert, dass es bei zeitgleichen Zugriffen verschiedener Benutzer zu Dateninkonsistenzen kommen kann.
Bei Vue.js handelt es sich um ein sogenanntes JavaScript-Framework, welches die Verknüpfung von HTML-, CSS- und JavaScript-Elementen stark vereinfacht und so auch den Entwicklungsprozess stark beschleunigt.
Aufgrund des zeitlichen Rahmens des Projekts, entschieden wir uns dazu, weiterführende Funktionen, wie, ein Buchungsportal für Buchungsanfragen von Interessenten, die Implementierung von Accounts mit gesonderten Rechten für Campingplatzbetreiber oder Preisvariantionen nach Datum, hier auszulassen.
Mit dem Entschluss war die grobe Planung abgeschlossen und die Umsetzung konnte beginnen.

<p><br><br></p>

UML-Modell der Ablaufstruktur:

<p align="center"><img src="./UML.png" alt="UML" width="55%"></p>

<p><br><br><br></p>

### Anforderungsanalyse

#### Funktionale Anforderungen

- Registrierung und Anmeldung:
  - Der Administrator sollte sich auf der Website anmelden können, um Zugriff auf die Funktionen zum Erstellen und Bearbeiten von Campingplätzen zu erhalten.
  - Die Nutzer sollten sich Registrieren und Anmelden können.
- Campingplatz erstellen:
  - Der Administrator sollte in der Lage sein, neue Campingplätze zu erstellen, indem er Informationen wie Name, Adresse, Beschreibung, usw. angibt.
- Campingplatz bearbeiten:
  - Der Administrator sollte in der Lage sein, bestehende Campingplätze zu bearbeiten, indem er Informationen wie Name, Adresse, usw. aktualisiert.
- Campingplatz suchen:
  - Nutzer sollten in der Lage sein, Campingplätze auf der Website zu suchen und dabei Kriterien wie Standort, Preis, Verfügbarkeit usw. angeben können.
- Campingplatz bewerte:
  - Nutzer sollten in der Lage sein, Campingplätze auf der Website zu bewerten, indem sie Sternebewertungen abgeben.

#### Nicht-funktionale Anforderungen:

- Benutzerfreundlichkeit:
  - Die Website sollte für den Administrator als auch für die Nutzer einfach zu bedienen sein.
- Sicherheit:
  - Die Website sollte sicher sein und sensible Informationen wie die Benutzerdaten schützen können.
- Leistung:
  - Die Website sollte reaktionsschnell sein, um ein nahtloses Benutzererlebnis zu gewährleisten.
- Skalierbarkeit:
  - Die Website sollte skalierbar sein und in der Lage, mit einer zunehmenden Anzahl von Nutzern umzugehen.

<p><br></p>

### Beschreibung

Als relevante Daten haben wir uns für die folgenden Attribute entschieden:

- Name des Campingplatzes
- Adresse des Campingplatzes
- Telefonnummer
- Öffnungs- und Schließzeiten
- Bewertung
- Preis
- Anzahl freier Zeltplätze
- diverse Extras (WC, dusche, spielplatz, tiereErlaubt, barrierefrei, bademöglichkeit, kiosk, WLAN, strom, waschmaschine)
- Eine BildURL für die Darstellung auf der Webseite

Der Einfachheit halber hat jeder Zeltplatz auf einem Campingplatz zu jeder Zeit den selben Preis, zudem gelten die identischen Öffnungs- und Schließzeiten des ganze Jahr über.
Durch die Implemierung einer `seeder`-Funktion ist es möglich vordefinierte Testdaten in die Datenbank zu integrieren, welche wir zur Anschauung verwenden wollen.

Unser Frontend sieht in der Admin-Ansicht wie folgt aus:

<p><br></p>
<p align="center"><img src="./Übersicht.png" alt="Frondend-Übersicht" width="55%"></p>

<p><br><br><br></p>
Links-oben befindet sich der "+" Knopf. Dieser existiert nur, wenn der Admin eingeloggt ist und öffnet ein Modal in welchem der Admin die Daten einfügt um einen neuen Campingplatz anzulegen.
<p><br></p> 
<p align="center"><img src="./Erstellen.png" alt="AddButton" width="55%"></p>
<p><br></p>
Auf der linken Seite befinden sich die Filteroptionen. Durch anklicken der Knöpfe wird innerhalb aller Datensätze gefiltert wodurch anschließend nur noch solche Datensätze angezeigt werden, die die gewählten Filteroptionen erfüllen. "Bewertung ab" führt ebenfalls eine Filterfunktion aus und  entfernt bei Auswahl einer gewünschten Mindestbewertung alle Campingplätze mit niedrigerer Bewertung als unsere Mindestbewertung aus der Darstellung. "Preis bis" arbeitet umgekehrt zur Bewertung und schließt alle Campingplätze mit höherem Preis aus, bedarf aber der Eingabe eines Maximalpreises via Textinputfeld.
Zentral befindet sich die Auflistung der (gefilterten) Campingplätze mit Angaben zur Adresse, Bewertung, Preis, ect.
Darüber befindet sich ein Suchfeld welches es ermöglicht einen bestimmten Campingplatz innerhalb unserer Datensätze zu finden oder alternativ unsere Datensätze nach Campingplätzen in einem bestimmten Ort zu filtern.

<p><br></p> 
Ausgewählte Filter und Darstellung:

<p><br></p> 
<p align="center"><img src="./Filter.png" alt="Filter" width="55%"></p>
<p><br></p>

Durch einen Klick auf den gewünschten Campingplatz öffnet sich ein Modal in welchem der Benutzer den jeweiligen Campingplatz bewerten kann.

<p><br></p>
<p align="center"><img src="./BewertungCPUserview.png" alt="BewertungCPUserview" width="55%"></p>
<p><br></p>

Selbiges Modal bietet aus Sicht des Admin-Accounts zusätzlich die Optionen den Campingplatz zu entfernen als auch den Campingplatz zu bearbeiten.

<p><br></p>
<p align="center"><img src="./BewertungCPAdminview.png" alt="BewertungCPAdminview" width="55%"></p>
<p><br></p>

Mit einem Klick auf "Campingplatz bearbeiten" öffnet sich ein anderes Modal welches alle zum Campingplatz zugehörigen Daten enthält. Diese Daten können hier überschrieben und anschließend gespeichert werden.

<p><br></p>
<p align="center"><img src="./Bearbeiten.png" alt="Bearbeiten" width="55%"></p>

<p><br><br></p>

Die Zielsetzung unseres Front-Ends war es, einen Anlaufpunkt für Interessenten zu erstellen, durch welchen der Benutzer die Datenbank nach für ihn relevanten Einträgen durchsuchen und filtern kann.
Gleichzeitig sollte auch das Layout den Benutzer nicht allzu sehr abschrecken.

<p><br></p>

### Testing

Im Zuge des Testings wurden immer wieder heuristische, manuelle End-to-End Black-Box-Testings durchgeführt.
Hierdurch konnten nach und nach Fehler wie z.B. nicht übereinstimmende Datentypen, in Backend und Datenbank, aufgedeckt und bereinigt werden.

<p><br><br></p>

### Projektablauf

Nachträglich haben wir exemplarisch den Ablauf des Projekts in einem Kanban-ähnlichen Board dargestellt.

<p><br></p>
<p align="center"><img src="./Kanban.png" alt="Kanban" width="55%"></p>
<p><br></p>

### Bewertung

Die Zielsetzung wurde weitestgehend eingehalten und das Projekt erfolgreich abgeschlossen.
Auftretende Probleme konnten durch Testings und Fehleranalysen meist schnell identifiziert und gemeinsam gelöst werden.

Nicht ganz optimal lief dabei aber vor allem die eigene Zeiteinteilung:

- das Aufhalten an und überarbeiten von Details hat deutlich mehr Zeit in Anspruch genommen als eingeplant war
- die begrenzte Erfahrung mit Backend-Technologien haben teilweise ebenfalls mehr Zeit in Anspruch genommen als erwartet

<p><br><br></p>
Insgesamt hat uns das Projekt dennoch sehr viel Spaß und neues Wissen bereitet.
